<?php
$username=filter_input(INPUT_POST ,'username');
$password=filter_input(INPUT_POST ,'password');
$gender=filter_input(INPUT_POST ,'gender');
$email=filter_input(INPUT_POST ,'email');
$phoneCode=filter_input(INPUT_POST ,'phoneCode');
$phone=filter_input(INPUT_POST ,'phone');

if(!empty($username)||!empty($password)||!empty($gender)||!empty($email)||!empty($phoneCode)||!empty($phone)){
$host="localhost";
$dbusername="root";
$dbpassword="";
$dbname="lg";
//create connection
$conn=new mysqli($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_error()){
die('Connect Error('.mysqli_connect_error().')'.mysqli_connect_error());
}
else{

$sql="INSERT INTO register (username, password, gender, email, phoneCode, phone)values('$username','$password','$gender','$email','$phoneCode','$phone')";

if($conn->query($sql)){
echo "<script>alert('registerd successfully')</script>";
echo "<script>window.open('inerst.php','_self')</script>";
}
else{
echo "error:".$sql ."<br>".$conn->error;
}
$conn->close();
}}
else{
echo "";
die();
}
?>